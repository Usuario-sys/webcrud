<?php
// Conexión a la base de datos
$servername = "localhost";
$username = "root";  // Usuario predeterminado en XAMPP
$password = "";      // Contraseña predeterminada en XAMPP
$dbname = "pagina";  // Nombre de tu base de datos

// Crear la conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Obtener los datos de la solicitud POST
$data = json_decode(file_get_contents("php://input"));

// Asegurarnos de que los datos estén disponibles
if (isset($data->nombre) && isset($data->cantidad) && isset($data->precio)) {
    $nombre = $conn->real_escape_string($data->nombre);
    $cantidad = (int)$data->cantidad;
    $precio = (float)$data->precio;

    // Consulta SQL para actualizar el producto en la base de datos
    $sql = "UPDATE productos SET cantidad = '$cantidad', precio = '$precio' WHERE nombre = '$nombre'";

    if ($conn->query($sql) === TRUE) {
        // Respuesta exitosa
        echo json_encode(['success' => true]);
    } else {
        // Error al actualizar
        echo json_encode(['success' => false, 'message' => 'Error al actualizar el producto: ' . $conn->error]);
    }
} else {
    // Si no se reciben datos
    echo json_encode(['success' => false, 'message' => 'Datos incompletos']);
}

// Cerrar la conexión
$conn->close();
?>
