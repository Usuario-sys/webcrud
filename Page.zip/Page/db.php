<?php

$CONEXION = mysqli_connect("localhost", "root", "", "pagina");

if (!$CONEXION) {
       throw new Exception("Error de conexión: " . mysqli_connect_error());
   }
   

?>
