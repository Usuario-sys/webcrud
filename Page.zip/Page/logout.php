<?php
session_start();

// Regenera el ID de sesión para prevenir ataques de fijación de sesión
session_regenerate_id(true);

// Verifica si la sesión está activa
if (isset($_SESSION['username'])) {
    // Destruye las variables de sesión
    session_unset(); 

    // Destruye la sesión
    session_destroy(); 

    // Eliminar la cookie de sesión (si existe)
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(
            session_name(), 
            '', 
            time() - 42000, 
            $params['path'], 
            $params['domain'], 
            $params['secure'], 
            $params['httponly']
        );
    }

    // Redirige de manera segura a la página de login (evitar redirecciones abiertas)
    header("Location: index.php");
    exit();
} else {
    // Si no hay sesión activa, redirigir directamente a la página de login
    header("Location: index.php");
    exit();
}
?>
