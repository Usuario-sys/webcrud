<?php
session_start(); // Asegúrate de iniciar la sesión al principio

// Generar el token CSRF si aún no está presente en la sesión
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); // Generar un token CSRF único
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión - Inventario</title>
    <link rel="stylesheet" href="src/css/styles_index.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
</head>
<body>
    <div class="login-container">
        <h2 class="text-center">Iniciar sesión</h2>
        
        <form action="validator.php" method="post">
            <!-- Token CSRF -->
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">

            <div class="input-group">
                <label for="username">Usuario</label>
                <input type="text" id="username" name="username" required aria-label="Nombre de usuario" value="<?php echo isset($_SESSION['username']) ? htmlspecialchars($_SESSION['username']) : ''; ?>">
                <?php
                if (isset($_SESSION['username_error']) && $_SESSION['username_error'] === true) {
                    echo "<div class='error-message-user'><i class='fa-solid fa-circle-exclamation'></i><p>Usuario incorrecto</p></div>";
                    unset($_SESSION['username_error']);  // Limpiar error de sesión
                }
                ?>
            </div>

            <div class="input-group">
                <label for="password">Contraseña</label>
                <input type="password" id="password" name="password" required minlength="12" maxlength="64" aria-label="Contraseña">
                <?php
                if (isset($_SESSION['password_error']) && $_SESSION['password_error'] === true) {
                    echo "<div class='error-message-password'><i class='fa-solid fa-circle-exclamation'></i><p>Contraseña incorrecta</p></div>";
                    unset($_SESSION['password_error']);  // Limpiar error de sesión
                }
                ?>
            </div>

            <button type="submit" class="btn-submit">Ingresar</button>
        </form>

        <?php
        if (isset($_SESSION['error']) && $_SESSION['error'] === 'missing') {
            echo "<p class='error-message'>Por favor, complete todos los campos.</p>";
            unset($_SESSION['error']);  // Limpiar error de sesión
        }
        ?>
    </div>
</body>
</html>
