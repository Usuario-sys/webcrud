<?php
session_start();  // Inicia la sesión
include("db.php");

// Verificar si el token CSRF está presente y si coincide con el token almacenado en la sesión
if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
    die("Error CSRF");
}

// Verificar si las variables necesarias están presentes
if (isset($_POST["username"]) && isset($_POST["password"])) {
    $USUARIO = filter_var($_POST["username"], FILTER_SANITIZE_STRING); // Sanitización de entrada
    $PASSWORD = $_POST["password"];

    // Usamos una consulta preparada para evitar inyecciones SQL
    $stmt = $CONEXION->prepare("SELECT * FROM user WHERE User = ?");
    $stmt->bind_param("s", $USUARIO);
    $stmt->execute();
    $RESULTADO = $stmt->get_result();

    // Inicializamos los parámetros de error
    $username_error = false;
    $password_error = false;

    // Si no se encuentra el usuario
    if ($RESULTADO->num_rows == 0) {
        $username_error = true;  // Usuario no encontrado
    } else {
        $USUARIO_DATA = $RESULTADO->fetch_assoc();

        // Verificar la contraseña hasheada (usando password_verify)
        if (!password_verify($PASSWORD, $USUARIO_DATA['Password'])) {
            $password_error = true;  // Contraseña incorrecta
        }
    }

    // Si hay errores, guardar en la sesión y redirigir
    if ($username_error || $password_error) {
        $_SESSION['error'] = 'auth';
        if ($username_error) {
            $_SESSION['username_error'] = true;  // Error de usuario
        }
        if ($password_error) {
            $_SESSION['password_error'] = true;  // Error de contraseña
        }
        $_SESSION['username'] = $USUARIO;  // Guardar el nombre de usuario para mostrarlo
        header("Location: index.php");
        exit();
    }

    // Si las credenciales son correctas, redirige al home
    $_SESSION['username'] = $USUARIO;  // Guardar nombre de usuario en la sesión
    header("Location: home.php");
    exit();

} else {
    // Si faltan campos necesarios, redirigir con el error de falta de datos
    $_SESSION['error'] = 'missing';
    header("Location: index.php");
    exit();
}

$stmt->close();
mysqli_close($CONEXION);
