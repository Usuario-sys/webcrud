<?php
// Conexión a la base de datos
$servername = "localhost";
$username = "root";  // Usuario predeterminado en XAMPP
$password = "";      // Contraseña predeterminada en XAMPP
$dbname = "pagina";  // Nombre de tu base de datos

// Crear la conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Obtener los datos de la solicitud POST
$data = json_decode(file_get_contents("php://input"));

// Asegurarnos de que los datos estén disponibles
if (isset($data->nombre)) {
    $nombre = $conn->real_escape_string($data->nombre);  // Escapar cualquier carácter especial en el nombre

    // Consulta SQL para eliminar el producto de la base de datos
    $sql = "DELETE FROM productos WHERE nombre = '$nombre'";

    // Ejecutar la consulta
    if ($conn->query($sql) === TRUE) {
        // Respuesta exitosa
        echo json_encode(['success' => true]);
    } else {
        // En caso de error, mostrar el error detallado
        echo json_encode(['success' => false, 'message' => 'Error al eliminar el producto: ' . $conn->error]);
    }
} else {
    // Si no se reciben datos
    echo json_encode(['success' => false, 'message' => 'Datos incompletos']);
}

// Cerrar la conexión
$conn->close();
?>
