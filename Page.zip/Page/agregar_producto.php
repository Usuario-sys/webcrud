<?php
// Conexión a la base de datos
$servername = "localhost";
$username = "root";  // Usuario predeterminado en XAMPP
$password = "";      // Contraseña predeterminada en XAMPP
$dbname = "pagina";  // Nombre de tu base de datos

// Crear la conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Obtener los datos de la solicitud POST
$data = json_decode(file_get_contents("php://input"));

// Asegurarnos de que los datos estén disponibles
if (isset($data->nombre) && isset($data->cantidad) && isset($data->precio)) {
    $nombre = $conn->real_escape_string($data->nombre);  // Escapar posibles caracteres especiales
    $cantidad = (int)$data->cantidad;                      // Asegurarse de que la cantidad sea un número entero
    $precio = (float)$data->precio;                         // Asegurarse de que el precio sea un número flotante

    // Consulta SQL para insertar el producto en la base de datos
    $sql = "INSERT INTO productos (nombre, cantidad, precio) VALUES ('$nombre', '$cantidad', '$precio')";

    if ($conn->query($sql) === TRUE) {
        // Respuesta exitosa
        echo json_encode(['success' => true, 'nombre' => $nombre, 'cantidad' => $cantidad, 'precio' => $precio]);
    } else {
        // Error al insertar
        echo json_encode(['success' => false, 'message' => 'Error al agregar el producto: ' . $conn->error]);
    }
} else {
    // Si no se reciben datos o faltan parámetros
    echo json_encode(['success' => false, 'message' => 'Datos incompletos']);
}

// Cerrar la conexión
$conn->close();
?>
