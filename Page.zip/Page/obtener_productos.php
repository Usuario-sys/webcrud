<?php
include("db.php");  // Asegúrate de tener la conexión a la base de datos configurada correctamente

$query = "SELECT * FROM productos";  // La consulta para obtener todos los productos
$result = mysqli_query($CONEXION, $query);

if ($result) {
    $productos = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $productos[] = $row;  // Almacenamos cada producto en un array
    }

    echo json_encode($productos);  // Devolvemos los productos como JSON
} else {
    echo json_encode(["error" => "No se pudieron obtener los productos."]);
}

mysqli_close($CONEXION);  // Cerrar la conexión a la base de datos
?>
