<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Control</title>
    <link rel="stylesheet" href="src/css/styles_home.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>

<body>
    <!-- Barra lateral de navegación -->
    <div class="barra-lateral">

        <div class="perfil">
       
            <p>Panel de Control</p>
        </div>
        
        <nav>
            <ul>
                <li class="submenu">
                    <span class="menu-principal"><i class="fas fa-clipboard-list"></i> Inventario ▼</span>
                    <ul class="submenu-opciones">
                        <li id="agregar-producto"><i class="fas fa-plus-circle"></i> Agregar Producto</li>                       
                        <li id="ver-inventario"><i class="fas fa-list-alt"></i> Ver Inventario</li>
                    </ul>
                </li>
            </ul>
        </nav>
    </div>
    

    <div class="contenido-principal">
        <header>           
            <h2>Inventario</h2>                   
            <div class="usuario-info">            
                <i class="fas fa-user-circle"></i> Administrador        
                <button id="logout-btn" class="logout-btn" onclick="logout();">         
                    <i class="fas fa-sign-out-alt"></i> 
                </button>
            </div>
        </header>

        <!-- Sección para agregar un nuevo producto al inventario -->
        <div id="seccion-agregar-producto">
            <h3>Agregar Nuevo Producto</h3>
            <form id="formulario-producto">
                <label>Nombre del Producto</label>
                <input type="text" id="nombre" required>             
                <label>Cantidad</label>
                <input type="number" id="cantidad" required>
                <label>Precio</label>
                <input type="number" id="precio" required>
                <button type="submit">Agregar Producto</button>
            </form>
        </div>
    
        <!-- Sección para ver la lista de productos del inventario -->
        <div id="seccion-ver-inventario" style="display: none;">
            <h3>Lista de Productos</h3>
            <table>
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Cantidad</th>
                        <th>Precio</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody id="lista-productos">
                    <!-- Aquí se mostrarán los productos -->
                </tbody>
            </table>
        </div>
    </div>
   
    <script src="src/js/scripts_home.js"></script>
    
</body>
</html>
