document.addEventListener("DOMContentLoaded", () => {
    // Elementos del DOM
    const formulario = document.getElementById("formulario-producto");
    const listaProductos = document.getElementById("lista-productos");
    const seccionAgregar = document.getElementById("seccion-agregar-producto");
    const seccionInventario = document.getElementById("seccion-ver-inventario");
    const submenu = document.querySelector(".menu-principal");
    const submenuOpciones = document.querySelector(".submenu-opciones");

    // Evento para mostrar/ocultar el submenú
    submenu.addEventListener("click", () => {
        submenuOpciones.style.display = submenuOpciones.style.display === "block" ? "none" : "block";
    });

    // Función para manejar el logout
    const logoutButton = document.getElementById("logout-btn");
    logoutButton.addEventListener("click", () => {
        window.location.replace("logout.php");  // Redirige al script logout.php para destruir sesión
    });

    // Evento para agregar un producto
    document.getElementById("agregar-producto").addEventListener("click", () => {
        seccionAgregar.style.display = "block"; 
        seccionInventario.style.display = "none";  
    });

    document.getElementById("ver-inventario").addEventListener("click", () => {
        seccionAgregar.style.display = "none";  
        seccionInventario.style.display = "block";  
        
        obtenerProductos(); // Llamar a la función que obtiene los productos desde la base de datos
    });

    formulario.addEventListener("submit", (e) => {
        e.preventDefault(); // Evitar recarga de página
        const nombre = document.getElementById("nombre").value;
        const cantidad = document.getElementById("cantidad").value;
        const precio = document.getElementById("precio").value;
        agregarProducto(nombre, cantidad, precio);
        formulario.reset();  // Resetear el formulario
    });

    // Función para agregar un producto a la tabla
    function agregarProducto(nombre, cantidad, precio) {
        fetch('agregar_producto.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ nombre, cantidad, precio })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Crear la fila del producto
                const fila = document.createElement("tr");
                fila.innerHTML = `
                    <td class="nombre">${data.nombre}</td>
                    <td class="cantidad">${data.cantidad}</td>
                    <td class="precio">$${data.precio}</td>
                    <td>
                        <button class="editar"><i class="fas fa-edit"></i></button>
                        <button class="guardar" style="display: none;"><i class="fas fa-save"></i></button>
                        <button class="eliminar"><i class="fas fa-trash"></i></button>
                    </td>
                `;
                listaProductos.appendChild(fila);

                // Agregar eventos para los botones de editar y eliminar
                agregarEventos(fila);
            } else {
                alert("Error al agregar el producto.");
            }
        })
        .catch(error => console.error('Error:', error));
    }

    // Función para agregar los eventos de eliminar y editar a cada fila
    function agregarEventos(fila) {
        // Evento para eliminar el producto
        fila.querySelector(".eliminar").addEventListener("click", () => {
            const nombreProducto = fila.querySelector(".nombre").textContent;
            fetch('eliminar_producto.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ nombre: nombreProducto })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    fila.remove();  // Eliminar la fila de la tabla si la respuesta es positiva
                } else {
                    alert("Error al eliminar el producto.");
                }
            })
            .catch(error => console.error('Error:', error));
        });

        // Evento para editar el producto
        fila.querySelector(".editar").addEventListener("click", () => {
            editarProducto(fila);
        });
    }

    // Función para editar el producto
    function editarProducto(fila) {
        const nombreCelda = fila.querySelector(".nombre");
        const cantidadCelda = fila.querySelector(".cantidad");
        const precioCelda = fila.querySelector(".precio");
        const editarBtn = fila.querySelector(".editar");
        const guardarBtn = fila.querySelector(".guardar");

        // Convertir las celdas en campos de entrada
        nombreCelda.innerHTML = `<input type="text" value="${nombreCelda.textContent}">`;
        cantidadCelda.innerHTML = `<input type="number" value="${cantidadCelda.textContent}">`;
        precioCelda.innerHTML = `<input type="number" value="${precioCelda.textContent.replace("$", "")}">`;

        // Cambiar visibilidad de los botones
        editarBtn.style.display = "none";
        guardarBtn.style.display = "inline-block";

        // Evento para guardar la edición
        guardarBtn.addEventListener("click", () => {
            const nombreProducto = nombreCelda.querySelector("input").value;
            const cantidadProducto = cantidadCelda.querySelector("input").value;
            const precioProducto = precioCelda.querySelector("input").value;

            // Actualizar producto en la base de datos
            fetch('editar_producto.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    nombre: nombreProducto,
                    cantidad: cantidadProducto,
                    precio: precioProducto
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Actualizar la interfaz con los nuevos valores
                    nombreCelda.innerHTML = nombreProducto;
                    cantidadCelda.innerHTML = cantidadProducto;
                    precioCelda.innerHTML = `$${precioProducto}`;

                    // Restaurar la visibilidad de los botones
                    editarBtn.style.display = "inline-block";
                    guardarBtn.style.display = "none";
                } else {
                    alert("Error al editar el producto.");
                }
            })
            .catch(error => console.error('Error:', error));
        });
    }

    // Función para obtener los productos desde la base de datos
    function obtenerProductos() {
        fetch('obtener_productos.php')  // Realiza una solicitud al archivo PHP
        .then(response => response.json())
        .then(data => {
            listaProductos.innerHTML = '';  // Limpiar la tabla antes de agregar los nuevos productos

            if (data && !data.error) {
                data.forEach(producto => {
                    const fila = document.createElement("tr");
                    fila.innerHTML = `
                        <td class="nombre">${producto.nombre}</td>
                        <td class="cantidad">${producto.cantidad}</td>
                        <td class="precio">$${producto.precio}</td>
                        <td>
                            <button class="editar"><i class="fas fa-edit"></i></button>
                            <button class="guardar" style="display: none;"><i class="fas fa-save"></i></button>
                            <button class="eliminar"><i class="fas fa-trash"></i></button>
                        </td>
                    `;
                    listaProductos.appendChild(fila);

                    // Agregar los eventos de editar y eliminar
                    agregarEventos(fila);
                });
            } else {
                listaProductos.innerHTML = '<tr><td colspan="4">No se pudieron cargar los productos.</td></tr>';
            }
        })
        .catch(error => console.error('Error:', error));
    }
});
